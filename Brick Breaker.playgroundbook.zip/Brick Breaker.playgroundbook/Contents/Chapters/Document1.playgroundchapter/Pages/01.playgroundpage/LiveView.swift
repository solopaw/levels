//
//  LiveView.swift
//  
//  Copyright © 2016-2020 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import BrickBreakerLiveView
import SPCLearningTrails


let liveViewController = BrickBreakerViewController()

liveViewController.backgroundImage = #imageLiteral(resourceName: "Background_1.png")
PlaygroundPage.current.liveView = liveViewController
